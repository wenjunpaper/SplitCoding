/*-----------------------------------------------------------------------------
 *  
 *  Name:		internal.c
 *  Description:	internal encoding
 *  Version:		1.0 (release)
 *  Author:		Xinwei Liu (lxw0724@pku.edu.cn)	 
 *  Date:		10/10/2018
 *   
 *-----------------------------------------------------------------------------*/

#include <stdio.h>

#include <stdlib.h>

#include <math.h>



int w,total;

//in the case [0,a]
int lemma1(int b, int lcp)

{

    int i;

    int count = 0;

    b = b+1;

    for(i = w-lcp-1; i >= 0; i--)
        if((b&(1<<i)) > 0)
            count++;
    return count;
}


//in the case [b,2^w-1]
int lemma2(int b, int lcp)

{

    int i;

    int count = 0;

    b = b-1;

    for(i = w-lcp-1; i >= 0; i--)
        if((b&(1<<i)) == 0)
            count++;
    return count;

}

void encoding(int left, int right, int we)
{

    int lcp = 0, m, n, internal;

    int c, d;

    if(left == right)

    {


        total += 1;


        return;

    }



    int i = we-1;

    //find the lcp
    while((left&(1<<i)) == (right&(1<<i)))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp); //compute the leftmost endpoint m

    n = m + (1<<(we-lcp))-1; //compute the rightmost endpoint n 




    if((left == m) && (right == n))

    {


        total += 1;


        return;

    }



    if(left == m)

    {
        //use DNF to count the prefixes
        internal = lemma1(right,w-we+lcp);

        total += internal;
        return;

    }

    if(right == n)

    {
        internal = lemma2(left,w-we+lcp);

        total += internal;

        return;

    }



     c = (m+n)>>1; //the middle point


    d = c+1;

    encoding(left,c,we-lcp); //count the number of prefixes recursively

    encoding(d,right,we-lcp);



}


int main()

{

    int a, b,i,j;

    long long sum,n;

    w = 1;


    while(w<17) //width from 1 to 16
    {
        total = 0;
        sum = 0;
        n = 0;

        int rrange = pow(2,w)-1;

        for(i = 0; i <= rrange; i++)
        {
            for(j = i; j <= rrange;j++)
            {

                encoding(i,j,w); //encode the range use internal coding

                n++;
                sum += total;
                total = 0;
            }

        }

        double average = sum*1.0/n;
        printf("w = %d, average range expansion ratio is %lf\n",w,average);
        w++;
    }


    return 0;

}

