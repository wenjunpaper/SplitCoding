/*-----------------------------------------------------------------------------
 *  
 *  Name:		splitcoding.c
 *  Description:	proposed splitcoding
 *  Version:		1.1 (release)
 *  Author:		Xinwei Liu (lxw0724@pku.edu.cn)	 
 *  Date:		05/03/2019
 *   
 *-----------------------------------------------------------------------------*/

#include <stdio.h>

#include <stdlib.h>

#include <math.h>

#include <time.h>

int w,total;


//in the case [0,a]
int lemma1(int b, int lcp)

{

    int i;

    int count = 0;

    b = b+1;

    for(i = w-lcp-1; i >= 0; i--)
        if((b&(1<<i)) > 0)
            count++;
    return count;
}


//in the case [b,2^w-1]
int lemma2(int b, int lcp)

{

    int i;

    int count = 0;

    b = b-1;

    for(i = w-lcp-1; i >= 0; i--)
        if((b&(1<<i)) == 0)
            count++;
    return count;

}

int encoding(int left, int right, int we)

{

    int lcp = 0, m, n, internal,external;

    int c, d;

    if(left == right)

    {

	total += 1;

        return -1;

    }



    int i = we-1;


    while((left&(1<<i)) == (right&(1<<i)))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp);

    n = m + (1<<(we-lcp))-1;




    if((left == m) && (right == n))

    {

        total += 1;


        return -1;

    }


    if(left == m)

    {
        internal = lemma1(right,w-we+lcp);

        external = lemma2(right+1,w-we+lcp);

        if(internal < external+1)
        {
            total += internal;
            return -1;
        }


        else

        {
            total += external+1;
            return w-(we-lcp);

        }

    }

    if(right == n)

    {

        internal = lemma2(left,w-we+lcp);

        external = lemma1(left-1,w-we+lcp);

        if(internal < external+1)
        {
            total += internal;
            return -1;
        }



        else

        {
            total += external+1;
            return w-(we-lcp);

        }

    }



    c = (m+n)/2;


    d = c+1;


    int lf = encoding(left,c,we-lcp);

    int rf = encoding(d,right,we-lcp);

    /*if((lf != -1)&&(lf == rf))
    {
	total--;
        return w-(we-lcp)-1;
    }*/
    return -1;

}


int main()

{

    int a, b,i,j;

    long long sum, n;

    w = 1;
	
    clock_t start,end;

    while(w<17)
    {
        total = 0;
        sum = 0;
        n = 0;

        int rrange = pow(2,w)-1;
		
		start = clock();

        for(i = 0; i <= rrange; i++)
        {
            for(j = i; j <= rrange;j++)
            {
                encoding(i,j,w);

                n++;
                sum += total;
                total = 0;
            }

        }
		
		end = clock();
		double time = (double)(end-start)*1000/CLOCKS_PER_SEC;

        double average = sum*1.0/n;
        printf("w = %d, average range expansion ratio is %lf, average time:%.5lfus\n",w,average,time*1000/n);
        w++;
    }

    return 0;

}

