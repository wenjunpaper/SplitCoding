/*-----------------------------------------------------------------------------
 *  
 *  Name:		external.c
 *  Description:	external encoding
 *  Version:		1.0 (release)
 *  Author:		Xinwei Liu (lxw0724@pku.edu.cn)	 
 *  Date:		10/10/2018
 *   
 *-----------------------------------------------------------------------------*/

#include <stdio.h>

#include <stdlib.h>

#include <math.h>



int w,intotal,totalex;

//in the case [0,a]
int lemma1(int b, int lcp)

{

    int i;

    int count = 0;

    b = b+1;

    for(i = w-lcp-1; i >= 0; i--)
        if((b&(1<<i)) > 0)
            count++;
    return count;
}


//in the case [b,2^w-1]
int lemma2(int b, int lcp)

{

    int i;

    int count = 0;

    b = b-1;

    for(i = w-lcp-1; i >= 0; i--)
        if((b&(1<<i)) == 0)
            count++;
    return count;

}


void inencoding(int left, int right, int we)
{

    int lcp = 0, m, n, internal;

    int c, d;

    if(left == right)
    {

        intotal += 1;


        return;
    }



    int i = we-1;

    //find the lcp
    while((left&(1<<i)) == (right&(1<<i)))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp); //compute the leftmost endpoint m

    n = m + (1<<(we-lcp))-1; //compute the rightmost endpoint n

    if((left == m) && (right == n))
    {

        intotal += 1;


        return;
    }



    if(left == m)
    {
        //use DNF to count the prefixes
        internal = lemma1(right,w-we+lcp);

        intotal += internal;
        return;
    }

    if(right == n)
    {
        internal = lemma2(left,w-we+lcp);

        intotal += internal;

        return;
    }



    c = (m+n)/2; //the middle point

    d = c+1;

    inencoding(left,c,we-lcp); //count the number of prefixes recursively

    inencoding(d,right,we-lcp);

}
void exencoding(int left, int right, int we)

{

    int lcp = 0, m, n, external=0;

    int c, d;

    if(left == right)
    {
        totalex += 1;
        return;
    }



    int i = we-1;


    while((left&(1<<i)) == (right&(1<<i)))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp);

    n = m + (1<<(we-lcp))-1;




    if((left == m) && (right == n))
    {
        totalex += 1;

        return;
    }

    external = lemma1(left-1,lcp);
    totalex += external;


    external = lemma2(right+1,lcp);
    totalex += external;
    totalex += 1;
    return;


}



int main()

{

    int a, b,i,j, total;

    long long sum,n;

    w = 1;


    while(w<17)
    {
        total = 0;
        sum = 0;
        n = 0;

        int rrange = pow(2,w)-1;

        for(i = 0; i <= rrange; i++)
        {
            for(j = i; j <= rrange;j++)
            {
                intotal = 0;
                totalex = 0;
                inencoding(i,j,w);
                exencoding(i,j,w);
                total = totalex>intotal?intotal:totalex;
                n++;
                sum += total;

            }

        }

        double average = sum*1.0/n;
        printf("w = %d, average range expansion ratio is %lf\n",w,average);
        w++;
    }


    return 0;

}

