/*-----------------------------------------------------------------------------
 *  
 *  Name:		optimal.c
 *  Description:	optimal encoding
 *  Version:		1.0 (release)
 *  Author:		Xinwei Liu (lxw0724@pku.edu.cn)	 
 *  Date:		05/03/2019
 *   
 *-----------------------------------------------------------------------------*/

#include <stdio.h>

#include <stdlib.h>

#include <math.h>


struct DFA

{

    struct DFA *p0;

    struct DFA *p1;

    int id;

}A,B,C ;
int w;
long long totalin,totalex;
struct DFA *p;


void inencoding(int left, int right, int we)
{

    int lcp = 0, m, n, internal,j;

    int c, d;

    if(left == right)
    {

        totalin += 1;


        return;
    }



    int i = we-1;

    //find the lcp
    while((left&(1<<i)) == (right&(1<<i)))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp); //compute the leftmost endpoint m

    n = m + (1<<(we-lcp))-1; //compute the rightmost endpoint n

    if((left == m) && (right == n))
    {

        totalin += 1;


        return;
    }



    if(left == m)
    {
        p = &A;
        j = 0;
        while(j < we-lcp)
        {

            if((right&(1<<j)) > 0)
            {

                if(p->id != 1)
                    totalin++;
                p = p->p1;
            }
            else
                p = p->p0;
            j++;
        }
        totalin++;
        return;
    }

    if(right == n)
    {
        p = &A;
        j = 0;
        left = n-left;
        while(j < we-lcp)
        {

            if((left&(1<<j)) > 0)
            {

                if(p->id != 1)
                    totalin++;
                p = p->p1;
            }
            else
                p = p->p0;
            j++;
        }
        totalin++;
        return;
    }



    c = (m+n)/2; //the middle point

    d = c+1;

    inencoding(left,c,we-lcp); //count the number of prefixes recursively

    inencoding(d,right,we-lcp);

}
void exencoding(int left, int right, int we)

{

    int lcp = 0, m, n, external=0,j;

    int c, d;

    if(left == right)
    {
        totalex += 1;
        return;
    }



    int i = we-1;


    while((left&(1<<i)) == (right&(1<<i)))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp);

    n = m + (1<<(we-lcp))-1;





    if((left == m) && (right == n))
    {
        totalex += 1;

        return;
    }

    p = &A;
    j = 0;
    left = left-1;
    while(j < we-lcp)
    {

       if((left&(1<<j)) > 0)
        {

           if(p->id != 1)
               totalex++;
            p = p->p1;
         }

        else
            p = p->p0;
        j++;
    }
    totalex++;


    p = &A;
    j = 0;
    right = right+1;
    right = n-right;
    while(j < we-lcp)
    {
       if((right&(1<<j)) > 0)
        {
           if(p->id != 1)
               totalex++;
            p = p->p1;
         }
        else
            p = p->p0;
        j++;
    }
    totalex++;

    totalex += 1;
    return;


}



int main()

{


    A.id = 1;
    B.id = 2;
    C.id = 3;



    A.p0 = &B;
    A.p1 = &A;



    B.p0 = &C;
    B.p1 = &A;



    C.p0 = &C;
    C.p1 = &B;

    int a, b,i,j, total;

    long long sum,n;

    w = 1;


    while(w<17)
    {
        total = 0;
        sum = 0;
        n = 0;

        int rrange = pow(2,w)-1;

        for(i = 0; i <= rrange; i++)
        {
            for(j = i; j <= rrange;j++)
            {
                totalin = 0;
                totalex = 0;
                inencoding(i,j,w);
                exencoding(i,j,w);
                total = totalex>totalin?totalin:totalex;
                n++;
                sum += total;

            }

        }

        double average = sum*1.0/n;
        printf("w = %d, average range expansion ratio is %lf\n",w,average);
        w++;
    }


    return 0;

}

