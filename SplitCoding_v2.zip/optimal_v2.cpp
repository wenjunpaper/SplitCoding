
#include <stdio.h>

#include <stdlib.h>

#include <math.h>

#include <time.h>
#include <string.h>


int w;
struct set
{
    int num;
    unsigned int dcnum[16];//the number of dont care bits
    unsigned int prefix[16]; // the value of prefix
    bool action[16];
};

void printBinary(int x,int len)
{
    int t = len-1;
    if(x < pow(2,len-1))
    {
        for(t = len-1;t >= 0 ;t--)
        {
            if(x >= pow(2,t))
                break;
            printf("0");

        }
    }
    while(t >= 0)
    {
        if(x&(1<<t))printf("1");
        else printf("0");
        t--;
    }
}

class entries
{
public:
    struct set acSet;
    struct set dnSet;
    entries()
    {
     memset(&acSet,0,sizeof(acSet));
     memset(&dnSet,0,sizeof(dnSet));
    }
    ~entries(){}
    void addacSetF(int lcp, bool action1, int prefix); //add a accept
    void adddnSetF(int lcp, bool action1, int prefix);

    void addacSetB(int lcp, bool action1, int prefix); //add a accept
    void adddnSetB(int lcp, bool action1, int prefix);

    void setdnFromac();//copy dn to ac
    void setacFromdn();

    void changeLastentryac();
    void changeLastentrydn(); //cover the father in the tree

    void addReverseLast(int flag);
    void reverseALL(int k);

    entries& operator +(const entries& en)
    {
        int n = acSet.num;
        acSet.num += en.acSet.num;
        memcpy(&acSet.prefix[n],&en.acSet.prefix,4*en.acSet.num);
        memcpy(&acSet.dcnum[n],&en.acSet.dcnum,4*en.acSet.num);
        memcpy(&acSet.action[n],&en.acSet.action,1*en.acSet.num);


        n = dnSet.num;
        dnSet.num += en.dnSet.num;
        memcpy(&dnSet.prefix[n],&en.dnSet.prefix,4*en.dnSet.num);
        memcpy(&dnSet.dcnum[n],&en.dnSet.dcnum,4*en.dnSet.num);
        memcpy(&dnSet.action[n],&en.dnSet.action,1*en.dnSet.num);
        return *this;
    }

    void printE();

};


void entries::printE() {
    if(acSet.num >= dnSet.num)
    {
        for(int i = dnSet.num-1; i > 0; i--)
        {
            printBinary(dnSet.prefix[i],w-dnSet.dcnum[i]);
            for(int j = 0; j < dnSet.dcnum[i]; j++)
                printf("*");
            if(dnSet.action[i]) printf("  -->a\n");
            else printf("  -->d\n");
        }
    }
    else
    {
        for(int i = acSet.num-1; i >= 0; i--)
        {
            printBinary(acSet.prefix[i],w-acSet.dcnum[i]);
            for(int j = 0; j < acSet.dcnum[i]; j++)
                printf("*");
            if(acSet.action[i]) printf("  -->a\n");
            else printf("  -->d\n");
        }
    }

}

void entries::reverseALL(int k) {

    int i = acSet.num;
    for(int j = 0; j < i; j++)
    {
        //acSet.prefix[j] = ~(acSet.prefix[j]);
		int temp = (1<< (w-k-acSet.dcnum[j]))-1;
		
        acSet.prefix[j] ^= temp;
    }
    i = dnSet.num;
    for(int j = 0; j < i; j++)
    {
        //dnSet.prefix[j] = ~(dnSet.prefix[j]);		
		int temp = (1<< (w-k-acSet.dcnum[j]))-1;
        dnSet.prefix[j] ^= temp;
    }
}

void entries::addReverseLast(int flag) {
    if(flag == 0)
    {
        /*acSet.num++;
        acSet.prefix[acSet.num-1] = acSet.prefix[acSet.num-2];
        acSet.action[acSet.num-1] = ~acSet.action[acSet.num-2];
        acSet.dcnum[acSet.num-1] = acSet.dcnum[acSet.num-2];*/
        addacSetB(w-acSet.dcnum[0],true,acSet.prefix[0]);
    }
    else
    {
        /*dnSet.num++;
        dnSet.prefix[dnSet.num-1] = dnSet.prefix[dnSet.num-2];
        dnSet.action[dnSet.num-1] = ~dnSet.action[dnSet.num-2];
        dnSet.dcnum[dnSet.num-1] = dnSet.dcnum[dnSet.num-2];*/
        adddnSetB(w-dnSet.dcnum[0],false,dnSet.prefix[0]);
    }
}

void entries::addacSetF(int lcp, bool action1, int prefix) {
    acSet.num++;
    acSet.prefix[acSet.num-1] = prefix;
    acSet.action[acSet.num-1] = action1;
    acSet.dcnum[acSet.num-1] = w-lcp;
}

void entries::adddnSetF(int lcp, bool action1, int prefix) {
    dnSet.num++;
    dnSet.prefix[dnSet.num-1] = prefix;
    dnSet.action[dnSet.num-1] = action1;
    dnSet.dcnum[dnSet.num-1] = w-lcp;
}

void entries::addacSetB(int lcp, bool action1, int prefix) {
    acSet.num++;
    for(int i = acSet.num-1; i > 0; i--)
    {
        acSet.prefix[i] = acSet.prefix[i-1];
        acSet.action[i] = acSet.action[i-1];
        acSet.dcnum[i] = acSet.dcnum[i-1];
    }

    acSet.prefix[0] = prefix;
    acSet.action[0] = action1;
    acSet.dcnum[0] = w-lcp;
}

void entries::adddnSetB(int lcp, bool action1, int prefix) {
    dnSet.num++;
    for(int i = dnSet.num-1; i > 0; i--)
    {
        dnSet.prefix[i] = dnSet.prefix[i-1];
        dnSet.action[i] = dnSet.action[i-1];
        dnSet.dcnum[i] = dnSet.dcnum[i-1];
    }

    dnSet.prefix[0] = prefix;
    dnSet.action[0] = action1;
    dnSet.dcnum[0] = w-lcp;
}

void entries::setdnFromac() {

    memcpy(&this->dnSet,&this->acSet,sizeof(struct set));

}

void entries::setacFromdn() {

    memcpy(&this->acSet,&this->dnSet,sizeof(struct set));
}

void entries::changeLastentryac() {

    acSet.prefix[0] /= 2;

    acSet.dcnum[0] += 1;

}

void entries::changeLastentrydn() {
    dnSet.prefix[0] /= 2;

    dnSet.dcnum[0] += 1;
}

struct DFA

{

    struct DFA *p0;

    struct DFA *p1;

    int id;

}A,B,C ;

long long totalin,totalex;
struct DFA *p;


void inencoding(int left, int right, int we, entries* entry)
{

    int lcp = 0, m, n, internal,j;

    int c, d;

    if(left == right)
    {
        entry->addacSetF(w,true,left);

        totalin += 1;


        return;
    }



    int i = we-1;

    //find the lcp
    while(i>0 &&((left&(1<<i)) == (right&(1<<i))))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp); //compute the leftmost endpoint m

    n = m + (1<<(we-lcp))-1; //compute the rightmost endpoint n

    if((left == m) && (right == n))
    {

        entry->addacSetF(w-we+lcp,true,left>>(we-lcp));
        totalin += 1;

        return;
    }



    if(left == m)
    {
        p = &A;
        j = 0;

        entry->addacSetF(we,true,right);
        entry->setdnFromac();
        entry->adddnSetB(we,false,right);
        while(j < we-lcp)
        {

            if((right&(1<<j)) > 0)
            {

                /*if(p->id != 1)
                {
                    totalin++;
                }
                */
                if(p->id == 1)
                {
                    entry->changeLastentryac();

                    entry->setdnFromac();
                    entry->addReverseLast(1);

                }
                if(p->id == 2)
                {
                    entry->changeLastentryac();

                    entry->setdnFromac();
                    entry->addReverseLast(1);
                    totalin++;

                }
                if(p->id == 3)
                {
                    entry->setacFromdn();
                    int temp = (right|(right&left))>>j;
                    entry->addacSetB(w-j,true,temp);
                    entry->changeLastentryac();

                    temp = (right-(1<<j)|(right&left))>>j;
                    entry->adddnSetF(w-j,true,temp);
                    entry->changeLastentrydn();
                    totalin++;

                }
                p = p->p1;
            }
            else
            {
                if(p->id == 1)
                {
                    int temp = (right+(1<<j)|(right&left))>>j;
                    entry->addacSetF(w-j,false,temp);
                    entry->changeLastentryac();

                    entry->changeLastentrydn();


                }
                if(p->id == 2)
                {
                    entry->changeLastentrydn();

                    entry->setacFromdn();
                    entry->addReverseLast(0);


                }
                if(p->id == 3)
                {


                    entry->changeLastentrydn();

                    entry->setacFromdn();
                    entry->addReverseLast(0);
                }

                p = p->p0;
            }
            j++;
        }
        totalin++;
        return;
    }

    if(right == n)
    {
        p = &A;
        j = 0;
        left = n-left;

        entry->addacSetF(we,true,left);
        entry->setdnFromac();
        entry->adddnSetB(we,false,left);

        while(j < we-lcp)
        {
            if((left&(1<<j)) > 0)
            {

                /*if(p->id != 1)
                {
                    totalin++;
                }
                */
                if(p->id == 1)
                {
                    entry->changeLastentryac();

                    entry->setdnFromac();
                    entry->addReverseLast(1);

                }
                if(p->id == 2)
                {
                    entry->changeLastentryac();

                    entry->setdnFromac();
                    entry->addReverseLast(1);
                    totalin++;

                }
                if(p->id == 3)
                {
                    entry->setacFromdn();
                    int temp = (left|(left&right))>>j;
                    entry->addacSetB(w-j,true,temp);
                    entry->changeLastentryac();

                    temp = (left-(1<<j)|(left&right))>>j;
                    entry->adddnSetF(w-j,true,temp);
                    entry->changeLastentrydn();
                    totalin++;

                }
                p = p->p1;
            }
            else
            {
                if(p->id == 1)
                {
                    int temp = (left+(1<<j)|(left&right))>>j;
                    entry->addacSetF(w-j,false,temp);
                    entry->changeLastentryac();

                    entry->changeLastentrydn();


                }
                if(p->id == 2)
                {
                    entry->changeLastentrydn();

                    entry->setacFromdn();
                    entry->addReverseLast(0);


                }
                if(p->id == 3)
                {


                    entry->changeLastentrydn();

                    entry->setacFromdn();
                    entry->addReverseLast(0);
                }

                p = p->p0;
            }
            j++;
        }
        entry->reverseALL(lcp);
        totalin++;
        return;
    }



    c = (m+n)/2; //the middle point

    d = c+1;

    //inencoding(left,c,we-lcp,entry); //count the number of prefixes recursively

    //inencoding(d,right,we-lcp,entry);
    entries entrya,entryb;


    we = we-lcp;
    i = we-1;
    int lcp2 = 0;
    //find the lcp
    while(i>0 && ((right&(1<<i)) == (d&(1<<i))))

        lcp2++, i--;

    p = &A;
    j = 0;


    entrya.addacSetF(w,true,right);
    entrya.setdnFromac();
    entrya.adddnSetB(w,false,right);


    while(j < we-lcp2)
    {

        if((right&(1<<j)) > 0)
        {

            if(p->id == 1)
            {
                entrya.changeLastentryac();

                entrya.setdnFromac();
                entrya.addReverseLast(1);

            }
            if(p->id == 2)
            {
                entrya.changeLastentryac();

                entrya.setdnFromac();
                entrya.addReverseLast(1);
                totalin++;

            }
            if(p->id == 3)
            {
                entrya.setacFromdn();
                int temp = (right)|(right&d)>>j;

                entrya.addacSetB(w-j,true,temp);
                entrya.changeLastentryac();

                temp = (right-(1<<j))|(right&d)>>j;
                entrya.adddnSetF(w-j,true,temp);
                entrya.changeLastentrydn();
                totalin++;

            }
            p = p->p1;
        }
        else
        {

            if(p->id == 1)
            {
                int temp = (right+(1<<j)|(right&d))>>j;

                entrya.addacSetF(w-j,false,temp);

                entrya.changeLastentrydn();


            }
            if(p->id == 2)
            {
                entrya.changeLastentrydn();

                entrya.setacFromdn();
                entrya.addReverseLast(0);


            }
            if(p->id == 3)
            {


                entrya.changeLastentrydn();

                entrya.setacFromdn();
                entrya.addReverseLast(0);
            }

            p = p->p0;
        }
        j++;
    }
    totalin++;

    i = we-1;
    lcp2 = 0;

    //find the lcp
    while(i>0 &&((left&(1<<i)) == (c&(1<<i))))
        lcp2++, i--;

    p = &A;
    j = 0;
    left = c-left;
    c = left>>(we-lcp)<<(we-lcp);

    entryb.addacSetF(w,true,left);
    entryb.setdnFromac();
    entryb.adddnSetB(w,false,left);

    while(j < we-lcp2)
    {

        if((left&(1<<j)) > 0)
        {

            /*if(p->id != 1)
            {
                totalin++;
            }
            */
            if(p->id == 1)
            {
                entryb.changeLastentryac();

                entryb.setdnFromac();
                entryb.addReverseLast(1);

            }
            if(p->id == 2)
            {
                entryb.changeLastentryac();

                entryb.setdnFromac();
                entryb.addReverseLast(1);
                totalin++;

            }
            if(p->id == 3)
            {
                entryb.setacFromdn();
                int temp = (left|(left&c))>>j;

                entryb.addacSetB(w-j,true,temp);
                entryb.changeLastentryac();

                temp = (left-(1<<j)|(left&c))>>j;
                entryb.adddnSetF(w-j,true,temp);


                entryb.changeLastentrydn();
                totalin++;

            }
            p = p->p1;
        }
        else
        {
            if(p->id == 1)
            {
                int temp = (left+(1<<j)|(left&(1<<(lcp+lcp2))))>>j;
                entryb.addacSetF(w-j,false,temp);
                entryb.changeLastentryac();

                entryb.changeLastentrydn();


            }
            if(p->id == 2)
            {
                entryb.changeLastentrydn();

                entryb.setacFromdn();
                entryb.addReverseLast(0);


            }
            if(p->id == 3)
            {


                entryb.changeLastentrydn();

                entryb.setacFromdn();
                entryb.addReverseLast(0);
            }

            p = p->p0;
        }
        j++;
    }
    entryb.reverseALL(lcp+lcp2);
    //printf("\na:\n");
    //entrya.printE();
    //printf("\nb:\n");

   // entryb.printE();
    //printf("\n");
    *entry = entrya+entryb;
    totalin++;
    return;



}
void exencoding(int left, int right, int we, entries* entry)
{

    int lcp = 0, m, n, external=0,j;

    int c, d;

    if(left == right)
    {
        entry->addacSetF(w,true,left);
        totalex += 1;
    return;
    }



    int i = we-1;


    while((left&(1<<i)) == (right&(1<<i)))

        lcp++, i--;



    m = left>>(we-lcp)<<(we-lcp);

    n = m + (1<<(we-lcp))-1;




    if((left == m) && (right == n))
    {
        entry->addacSetF(w-we+lcp,true,left>>(we-lcp));
        totalex += 1;

        return;
    }

    p = &A;
    j = 0;
    left = left-1;
    while(j < we-lcp)
    {

        if((left&(1<<j)) > 0)
        {

            /*if(p->id != 1)
            {
                totalin++;
            }
            */
            if(p->id == 1)
            {
                entry->changeLastentryac();

                entry->setdnFromac();
                entry->addReverseLast(1);

            }
            if(p->id == 2)
            {
                entry->changeLastentryac();

                entry->setdnFromac();
                entry->addReverseLast(1);
                totalex++;

            }
            if(p->id == 3)
            {
                entry->setacFromdn();
                int temp = (left|(right&left))>>j;
                entry->addacSetB(w-j,true,temp);
                entry->changeLastentryac();

                temp = (left-(1<<j)|(right&left))>>j;
                entry->adddnSetF(w-j,true,temp);
                entry->changeLastentrydn();
                totalex++;

            }
            p = p->p1;
        }
        else
        {
            if(p->id == 1)
            {
                int temp = (left+(1<<j)|(right&left))>>j;
                entry->addacSetF(w-j,false,temp);
                entry->changeLastentryac();

                entry->changeLastentrydn();


            }
            if(p->id == 2)
            {
                entry->changeLastentrydn();

                entry->setacFromdn();
                entry->addReverseLast(0);


            }
            if(p->id == 3)
            {


                entry->changeLastentrydn();

                entry->setacFromdn();
                entry->addReverseLast(0);
            }

            p = p->p0;
        }
        j++;
    }
    totalex++;


    p = &A;
    j = 0;
    right = right+1;
    right = n-right;
    while(j < we-lcp)
    {
        if((right&(1<<j)) > 0)
        {

            /*if(p->id != 1)
            {
                totalin++;
            }
            */
            if(p->id == 1)
            {
                entry->changeLastentryac();

                entry->setdnFromac();
                entry->addReverseLast(1);

            }
            if(p->id == 2)
            {
                entry->changeLastentryac();

                entry->setdnFromac();
                entry->addReverseLast(1);
                totalex++;

            }
            if(p->id == 3)
            {
                entry->setacFromdn();
                int temp = (right|(left&right))>>j;
                entry->addacSetB(w-j,true,temp);
                entry->changeLastentryac();

                temp = (right-(1<<j)|(left&right))>>j;
                entry->adddnSetF(w-j,true,temp);
                entry->changeLastentrydn();
                totalex++;

            }
            p = p->p1;
        }
        else
        {
            if(p->id == 1)
            {
                int temp = (right+(1<<j)|(left&right))>>j;
                entry->addacSetF(w-j,false,temp);
                entry->changeLastentryac();

                entry->changeLastentrydn();


            }
            if(p->id == 2)
            {
                entry->changeLastentrydn();

                entry->setacFromdn();
                entry->addReverseLast(0);


            }
            if(p->id == 3)
            {


                entry->changeLastentrydn();

                entry->setacFromdn();
                entry->addReverseLast(0);
            }

            p = p->p0;
        }
        j++;
    }
    totalex++;

    entry->adddnSetB(0,true,0);
    totalex += 1;
    return;


}



int main(int argc , char*args[])

{


    A.id = 1;
    B.id = 2;
    C.id = 3;



    A.p0 = &B;
    A.p1 = &A;



    B.p0 = &C;
    B.p1 = &A;



    C.p0 = &C;
    C.p1 = &B;

    int a, b,i,j, total;

    long long sum,n;

    clock_t start,end;


    //w = atoi(args[3]);
    w = 1;


    while(w<17)
    {
        total = 0;
        sum = 0;
        n = 0;

        int rrange = pow(2,w)-1;

	start = clock();

        for(i = 0; i <= rrange; i++)
        {
            for(j = i; j <= rrange;j++)
            {
                entries entries1,entries2;
                totalin = 0;
                totalex = 0;
                inencoding(i,j,w,&entries1);
                exencoding(i,j,w,&entries2);
                total = totalex>totalin?totalin:totalex;
                //total = totalin;
                n++;
                sum += total;

            }

        }
        /*i = atoi(args[1]);
        j = atoi(args[2]);
        printf("encode:[");
        printBinary(i,w);
        printf(",");
        printBinary(j,w);
        printf("]\n");*/
        //inencoding(i,j,w,&entries1);
        //entries1.printE();

	end = clock();

    double average = sum*1.0/n;
	double time = (double)(end-start)*1000/CLOCKS_PER_SEC;
	
        printf("w = %d, average range expansion ratio is %lf, average time:%.5lfus\n",w,average,time*1000/n);
        w++;
    }


    return 0;

}

