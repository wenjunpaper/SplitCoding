Average range expansion ratio over all possible ranges for different width
1. internal encoding: internal.c 
2. external encoding: external.c
3. optimal encoding: optimal.c
4. splitcoding: splitcoding.c


